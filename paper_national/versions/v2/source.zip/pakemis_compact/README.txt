PAKEMIS — COMPACT EDITORIAL REVISION
1 October 2026

Title: A national greenhouse gas emissions inventory for Pakistan, 2015–2024

Start with pakemis_rewritten.pdf. This is a 10-page two-column reading copy,
with four figures and one product table. The main text has been substantially
shortened as well as reformatted; the previous 29-page copy was single-column.
Page counts therefore should not be treated as a measure of the text reduction.
Detailed sector equations, source records and reporting tables are preserved in
technical_supplement.pdf (9 pages), intended as repository technical documentation.
The project remains one national flagship paper.

FILES AND BUILD

pakemis_rewritten.tex: complete editable main paper, including bibliography.
submission.tex: wrapper that selects the official single-column manuscript mode.
technical_supplement.tex: editable technical documentation.
figures/: four vector PDF figures, PNG previews and plotting scripts.
data/: six small CSVs transcribed from numerical results in the supplied manuscript.
editorial_notes.txt: scientific corrections and unresolved author decisions.
ESSD_submission_requirements.txt: researched journal requirements and policy links.
package_manifest.json: file hashes and document checks.

Use a full TeX Live or MiKTeX installation with the official Copernicus dependencies.
Run from this folder:
  pdflatex pakemis_rewritten.tex
  pdflatex pakemis_rewritten.tex
  pdflatex technical_supplement.tex
  pdflatex technical_supplement.tex
For a single-column review-layout manuscript, run pdflatex submission.tex twice.
The official Copernicus class and its accompanying support files are included.
Bibliographies are inline, so BibTeX is not needed for these sources.

To recreate the figures with Python 3, Matplotlib and NumPy:
  python figures/plot_construction.py
  python figures/plot_figures.py
See figures/README.md for provenance and interpretation restrictions.

EDITORIAL AND SCIENTIFIC STATUS

The revision uses more direct scientific prose and moves procedural detail out of
the main narrative. It preserves qualifications that affect interpretation.
The figures show product construction, emissions composition and trajectory,
timing evidence and conditional uncertainty, and external comparison diagnostics.
They are based on the supplied manuscript; no inventory engine, Monte Carlo
simulation, external comparison or spatial allocation was rerun for this edit.

A national emissions map needs the actual release grid and boundary inputs.
A useful additional figure would show annual native-gas emissions at 0.05 degrees,
with units, reporting year, unallocated mass and the spatial-proxy limitations
specified. Derive it from the released NetCDF rather than from a reconstructed
illustration. Confirm the reference configuration and release before production.

This remains an editorial working draft. Repository review access/DOI, release
identity, source and product licensing, unresolved accounting questions and the
journal's AI policy still require author resolution. The more natural prose does
not change the nature of the assistance used. See editorial_notes.txt.
