# Compact manuscript figures 1–4

Figures 2–4 are editorial replots of printed numerical results in the supplied `paper_national(2).pdf` (75 pages). They were not produced by running the PakEmis inventory engine, repeating Monte Carlo draws, downloading an external inventory, or recalculating a spatial comparison. The companion CSVs preserve the transcribed values and source locations. No maps or distribution shapes were inferred.

## Figure 1: data-product construction

`fig1_data_products.pdf` is a schematic of relationships documented in the supplied manuscript and reproduced in the main methods: annual emissions, monthly timing weights, annual location weights, the reference-year monthly grid, and separately recorded unallocated mass. Arrows express calculation dependencies; they do not encode observed fluxes or data quality. No geographical coordinates or empirical values were invented. Run `python figures/plot_construction.py` from the package folder to recreate its PDF and PNG preview. Its plotting code is included in the package manifest. This figure was visually inspected after inclusion in the compiled paper.

## Files and reproduction (Figures 2–4)

Run from any working directory:

```bash
python /absolute/path/to/pakemis_compact/figures/plot_figures.py
```

Requirements: Python 3, Matplotlib, NumPy. Input CSVs are read relative to the script from `../data`. The script writes vector PDFs, 180 dpi PNG previews, and `figure_manifest.json` containing hashes of its inputs, itself, and rendered outputs. PDFs are exactly 7.2 inches wide; their heights are 4.0, 3.9, and 3.95 inches, respectively. The smallest specified text is 9 pt. Include each at 7.2 inches (or at its natural size) to preserve that minimum; scaling down scales text too. Fonts are embedded CID TrueType DejaVu Sans; the figures use no raster data layer.

## Suggested captions

**Figure 2. Module composition and annual national reconstruction.** (a) Reported FY2023–24 totals for the ten accounting modules. Abbreviated labels denote oil and gas fugitives, industrial fuel combustion, and domestic aviation; the power, transport, IPPU, and rail modules include the additions described in the methods. (b) National totals for FY2015–16 to FY2023–24 under the reference accounting configuration. Both panels use AR5 100-year global warming potentials. Values in (a) are rounded to 0.01 Mt CO₂e; the annual series was transcribed at 0.001 Mt CO₂e and selected labels are displayed at 0.1 Mt CO₂e. These are deterministic inventory estimates; the line does not imply that differences between years are statistically resolved.

**Figure 3. Monthly timing evidence and conditional national parameter uncertainty.** (a) FY2023–24 CO₂e-weighted shares assigned to TE1, observed monthly source activity; TE2, reconstructed monthly administrative activity; TE3, process-informed temporal profiles; and TE4, flat or weakly constrained temporal profiles. The classes describe evidence for temporal allocation rather than the accuracy of annual emissions. (b) Deterministic national reference total (diamond and vertical dashed guide), reported Monte Carlo medians (circles), and 2.5–97.5 percentile intervals (horizontal segments) under within-module parameter sharing and an alternative with cross-module sharing of selected fuel factors. The two simulations have the same printed median but slightly different interval limits, which are shown individually. The intervals describe parameter uncertainty conditional on the reference configuration; structural scenarios and unquantified omissions are excluded. No probability density is inferred from the printed quantiles.

**Figure 4. Factor-vintage sensitivity and geographic disagreement with external inventories.** (a) Reported managed-soils estimates for the PakEmis FY2023–24 reference, replacement of EF1 by the 2006 aggregate factor, and replacement of both EF1 and the pasture direct factors on their respective subitems; the external FAOSTAT total is for CY2023. The scenario bars are deterministic substitutions, not uncertainty bounds. The fiscal/calendar period difference and shared activity-data lineage constrain interpretation of agreement. (b) Reported PakEmis/EDGAR v8.1 SO₂ ratios for FY2021–22 at national and provincial scales, with unity shown by the dashed line. EDGAR calendar-year estimates were blended for the fiscal-year comparison described in the source manuscript. The comparison uses the source's covered scope, including its omission of power-sector coal; discrepancies can reflect coverage, factors, controls, and geographic allocation. Neither national agreement nor a provincial ratio is observational validation.

## Input provenance and interpretation limits

| CSV in `../data` | Printed source | Values and restrictions |
|---|---|---|
| `module_totals.csv` | Table 3, p. 15 | Ten FY2023–24 module totals in Mt CO₂e: 223.45, 63.37, 41.93, 37.91, 29.47, 25.54, 24.69, 22.58, 0.39, 0.30. Their sum is 469.63 because of component rounding; the reported national reference is 469.64. Accounting modules are not a one-to-one IPCC-category partition. |
| `annual_national_series.csv` | Figure 2, p. 21 | FY2015–16 through FY2023–24: 401.090, 427.074, 450.742, 446.846, 446.733, 479.511, 497.774, 456.621, 469.638 Mt CO₂e. Values were transcribed from the supplied figure. |
| `reference_temporal_evidence.csv` | Section 4.6, p. 23 | Reference-year TE1–TE4 shares 0.90, 27.74, 19.23, 52.13%; total 100%. These are emission-mass shares, not counts of products or months. They do not describe the full nine-year evidence mixture. |
| `national_uncertainty.csv` | Section 4.9 and Table 6, pp. 36 and 39 | Accounting reference 469.64; within-module sharing median 474.20 and interval 424.31–550.79; shared fuel factors median 474.20 and interval 424.29–550.94 Mt CO₂e. These are printed results from 100,000 reported draws; no draws were repeated. |
| `managed_soils_factor_scenarios.csv` | Table 10 and Section 6.4, pp. 51 and 55–56 | Reference 28.53; 2006 EF1 40.43; 2006 EF1 plus pasture factors 54.72; FAOSTAT 58.50 Mt CO₂e. The first three refer to FY2023–24, the last to CY2023. Factor substitution is a diagnostic, not calibration to an external truth. |
| `provincial_so2_ratios.csv` | Section 6.5, pp. 56–57 | Pakistan 0.96; Punjab 1.30; Khyber Pakhtunkhwa 1.72; Balochistan 2.06; Sindh 0.21. Dimensionless ratios, not percentages. Covered-scope accounting and unresolved spatial-assignment conflicts limit interpretation. |

All page numbers refer to the supplied latest manuscript, not the revised compact manuscript. No temporal confidence band, national structural envelope, gridded map, or empirically estimated probability density is supplied, because the available material does not establish those objects.

## Verification

The six CSV inputs were read successfully, the ten-module total was checked against rounding of the reported national total, and the four temporal shares were checked to sum to 100%. All three PNG previews were visually inspected for layout. `pdfinfo` confirmed one-page PDFs with 518.4-point width (7.2 inches), and `pdffonts` confirmed embedded TrueType fonts. These checks concern transcription and figure production; they do not establish scientific reproducibility of the original calculations.
