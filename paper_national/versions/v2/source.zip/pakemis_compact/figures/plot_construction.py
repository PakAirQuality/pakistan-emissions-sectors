"""Scientific schematic of documented data-product relationships; no empirical map."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'ps.fonttype':42})
out=Path(__file__).resolve().parent
fig,ax=plt.subplots(figsize=(7.4,4.25)); ax.set_xlim(0,10);ax.set_ylim(-.55,5.5);ax.axis('off')
blue='#245A81';green='#267263';grey='#536170'
def box(x,y,w,h,title,body,edge=blue,fill='#F2F6F9'):
 p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.05,rounding_size=0.07',linewidth=1,edgecolor=edge,facecolor=fill);ax.add_patch(p)
 ax.text(x+w/2,y+h-.24,title,ha='center',va='top',fontsize=9.5,fontweight='bold',color=edge)
 ax.text(x+w/2,y+.17,body,ha='center',va='bottom',fontsize=9,color='#18242F',linespacing=1.4)
def arrow(a,b,label=None,lpos=None):
 ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=11,linewidth=1.05,color=grey,connectionstyle='arc3,rad=0'))
 if label:ax.text(*lpos,label,ha='center',va='center',fontsize=8.5,color=grey,bbox={'facecolor':'white','edgecolor':'none','pad':1.7})
box(.1,2.1,2.4,1.45,'Annual emissions','Activity × emission factor\nBy source, gas and year')
box(3.8,4.0,2.45,1.15,'Monthly estimates','July–June profiles\nTiming evidence recorded')
box(3.8,1.95,2.45,1.15,'Annual grids','Located sources and proxies\nNine fiscal years')
box(7.5,2.85,2.35,1.6,'Monthly grid','FY2023–24\n0.05° native-gas mass',edge=green,fill='#F1F7F3')
box(3.8,.25,2.45,1.18,'Unallocated mass','Mass without supported\nplacement',edge=grey,fill='#F4F4F4')
arrow((2.5,3.25),(3.78,4.55),'Timing weights',(3.04,4.1))
arrow((2.5,2.65),(3.78,2.65),'Location weights',(3.11,2.93))
arrow((2.5,2.17),(3.78,.86))
arrow((6.28,4.55),(7.47,4.05))
arrow((6.28,2.65),(7.47,3.26))

ax.text(.14,-.22,'Checks: monthly sums = annual mass; located + unallocated = national mass',fontsize=9,color=grey,va='top')
fig.subplots_adjust(left=.02,right=.98,bottom=.11,top=.96)
fig.savefig(out/'fig1_data_products.pdf',bbox_inches='tight')
fig.savefig(out/'fig1_data_products.png',dpi=200,bbox_inches='tight')
