#!/usr/bin/env python3
"""Compact editorial figures from manuscript-transcribed data, not engine reruns."""
from pathlib import Path
import csv
import hashlib
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent
DATA = HERE.parent / 'data'
BLUE = '#0072B2'
ORANGE = '#D55E00'
TEAL = '#009E73'
GREY = '#727C85'
INK = '#202830'
GRID = '#E3E7EA'
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 9,
    'axes.titlesize': 10.5, 'axes.labelsize': 9,
    'xtick.labelsize': 9, 'ytick.labelsize': 9,
    'axes.labelcolor': INK, 'text.color': INK,
    'xtick.color': INK, 'ytick.color': INK,
    'axes.edgecolor': '#65717B', 'axes.linewidth': .7,
    'axes.spines.top': False, 'axes.spines.right': False,
    'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none',
    'figure.facecolor': 'white', 'savefig.facecolor': 'white',
})

def rows(name):
    with (DATA/name).open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

def clean(ax, axis='x'):
    ax.set_axisbelow(True)
    ax.grid(axis=axis, color=GRID, linewidth=.65)
    if axis == 'x':
        ax.spines['left'].set_visible(False)
        ax.tick_params(axis='y', length=0)

def panel(ax, text):
    ax.set_title(text, loc='left', weight='bold', pad=14)

def save(fig, stem):
    # Deliberately do not use bbox_inches='tight': all figures retain exactly
    # 7.2-inch width, so printed font sizes stay predictable on inclusion.
    fig.savefig(HERE/f'{stem}.pdf', metadata={
        'Title':stem.replace('_',' '), 'Author':'Rehan Ahmad / PAQI',
        'Subject':'Editorial replot of manuscript-transcribed values; no inventory engine rerun',
        'Creator':'Matplotlib; plot_figures.py'})
    fig.savefig(HERE/f'{stem}.png', dpi=180)
    plt.close(fig)

# Figure 2: module composition and annual reconstruction.
module = rows('module_totals.csv')
annual = rows('annual_national_series.csv')
v = np.array([float(r['emissions_Mt_CO2e']) for r in module])
total = np.array([float(r['emissions_Mt_CO2e']) for r in annual])
assert len(module)==10 and len(annual)==9
assert abs(v.sum()-469.64)<.05
labels = ['Agriculture','Power','Transport','Waste','Residential','IPPU',
          'Fugitives','Industry','Railways','Aviation']
fig = plt.figure(figsize=(7.2, 4.0))
a = fig.add_axes([.15,.19,.345,.69])
y = np.arange(10)
a.barh(y,v,height=.64,color=BLUE)
a.set_yticks(y,labels)
a.invert_yaxis()
a.set_xlim(0,270)
a.set_xticks([0,100,200])
a.set_xlabel('Mt CO$_2$e (AR5)')
for yy, val in zip(y,v):
    a.text(val+4,yy,f'{val:.2f}',va='center',fontsize=9)
clean(a)
panel(a,'(a) Module totals')
a.text(0,1.015,'FY2023–24',transform=a.transAxes,fontsize=9,color='#59656E')
b = fig.add_axes([.65,.19,.325,.69])
x=np.arange(9)
b.plot(x,total,color=BLUE,linewidth=1.65,marker='o',markersize=4)
b.set_xlim(-.4,8.45)
b.set_ylim(385,525)
b.set_yticks([400,450,500])
b.set_xticks([0,2,4,6,8],['2015–16','2017–18','2019–20','2021–22','2023–24'],rotation=45,ha='right')
b.set_xlabel('Fiscal year',labelpad=4)
b.set_ylabel('Mt CO$_2$e (AR5)',labelpad=3)
for idx,dy in [(0,9),(6,9),(8,9)]:
    b.annotate(f'{total[idx]:.1f}',(idx,total[idx]),xytext=(0,dy),textcoords='offset points',ha='center',fontsize=9)
clean(b,'y')
panel(b,'(b) Annual totals')
save(fig,'fig2_inventory')

# Figure 3: timing evidence and conditional national parameter intervals.
ev = rows('reference_temporal_evidence.csv')
share=np.array([float(r['share_percent']) for r in ev])
assert abs(share.sum()-100)<1e-9
unc=rows('national_uncertainty.csv')
fig=plt.figure(figsize=(7.2,3.9))
a=fig.add_axes([.09,.205,.34,.64])
y=np.arange(4)
a.barh(y,share,height=.53,color=[TEAL,BLUE,ORANGE,GREY])
a.set_yticks(y,[r['evidence_class'] for r in ev])
a.invert_yaxis()
a.set_xlim(0,66)
a.set_xticks([0,20,40,60])
a.set_xlabel('Emission-weighted share (%)')
for yy,val in zip(y,share):
    a.text(val+1.2,yy,f'{val:.2f}',va='center',fontsize=9)
clean(a)
panel(a,'(a) Monthly evidence')
a.text(0,1.015,'FY2023–24',transform=a.transAxes,fontsize=9,color='#59656E')
b=fig.add_axes([.57,.205,.405,.64])
b.set_xlim(411,568)
b.set_ylim(-.45,2.65)
b.set_yticks([])
b.set_xticks([425,475,525,565])
b.set_xlabel('National emissions (Mt CO$_2$e, AR5)')
b.spines['left'].set_visible(False)
b.axvline(float(unc[0]['point_Mt_CO2e']),color='#A3ABB1',lw=.8,linestyle=(0,(2,3)),zorder=0)
b.text(414,2.49,'Deterministic reference',fontsize=9,va='center')
b.plot(float(unc[0]['point_Mt_CO2e']),2.12,marker='D',markersize=5.7,color=INK,linestyle='none')
b.text(485,2.12,'469.64',fontsize=9,va='center')
for yy,case,label,color in [(1.15,unc[1],'Within-module sharing',BLUE),(.10,unc[2],'Shared fuel factors',ORANGE)]:
    lo,hi,med=map(float,[case['p025_Mt_CO2e'],case['p975_Mt_CO2e'],case['point_Mt_CO2e']])
    b.text(414,yy+.35,label,fontsize=9,va='center')
    b.hlines(yy,lo,hi,color=color,lw=1.65)
    b.vlines([lo,hi],yy-.07,yy+.07,color=color,lw=1.1)
    b.plot(med,yy,marker='o',markersize=5.5,color=color,linestyle='none')
    for val in [lo,med,hi]:
        b.annotate(f'{val:.2f}',(val,yy),xytext=(0,-13),textcoords='offset points',ha='center',fontsize=9)
panel(b,'(b) Parameter uncertainty')
fig.text(.57,.045,'Circles: median; lines: 2.5–97.5 percentiles.',fontsize=9)
save(fig,'fig3_evidence_uncertainty')

# Figure 4: soil factor scenarios and geographically disaggregated SO2 ratios.
soil=rows('managed_soils_factor_scenarios.csv')
sv=[float(r['emissions_Mt_CO2e']) for r in soil]
r=rows('provincial_so2_ratios.csv')
fig=plt.figure(figsize=(7.2,3.95))
a=fig.add_axes([.17,.245,.325,.59])
y=np.arange(4)
a.barh(y,sv,color=[BLUE,BLUE,BLUE,GREY],height=.56)
a.set_yticks(y,['Reference','2006 EF1','2006 EF1 +\npasture','FAOSTAT'])
a.invert_yaxis()
a.set_xlim(0,74)
a.set_xticks([0,20,40,60])
a.set_xlabel('Managed soils (Mt CO$_2$e, AR5)')
for yy,val in zip(y,sv):
    a.text(val+1.4,yy,f'{val:.2f}',va='center',fontsize=9)
clean(a)
panel(a,'(a) Factor scenarios')
fig.text(.17,.12,'PakEmis: FY2023–24',fontsize=9)
fig.text(.17,.065,'FAOSTAT: CY2023',fontsize=9)
b=fig.add_axes([.715,.245,.255,.59])
y=np.arange(5)
for yy,row in zip(y,r):
    rr=float(row['pakemis_to_edgar_ratio'])
    b.plot(rr,yy,marker='D' if yy==0 else 'o',color=INK if yy==0 else BLUE,markersize=5.5,linestyle='none',zorder=3)
    b.annotate(f'{rr:.2f}',(rr,yy),xytext=(7,0),textcoords='offset points',va='center',fontsize=9)
b.axvline(1,color='#65717B',lw=.9,linestyle=(0,(4,3)))
b.set_ylim(4.6,-.6)
b.set_xlim(0,2.64)
b.set_xticks([0,1,2])
b.set_yticks(y,['Pakistan','Punjab','Khyber\nPakhtunkhwa','Balochistan','Sindh'])
b.set_xlabel('PakEmis / EDGAR')
clean(b)
panel(b,'(b) SO$_2$ ratios')
fig.text(.715,.12,'FY2021–22',fontsize=9)
fig.text(.585,.065,'EDGAR v8.1: calendar-year blend',fontsize=9)
save(fig,'fig4_validation')

paths=sorted(list(DATA.glob('*.csv'))+list(HERE.glob('fig[234]*.pdf'))+list(HERE.glob('fig[234]*.png'))+[Path(__file__).resolve()])
manifest={'basis':'Printed manuscript values only; no inventory-engine run or new map calculation',
          'source':'Supplied paper_national(2).pdf',
          'width_inches':7.2,'minimum_font_points':9,
          'files':[{'path':str(p.relative_to(HERE.parent)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in paths]}
(HERE/'figure_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Created compact Figures 2–4, vector PDFs and PNG previews, from six transcribed input CSVs.')
